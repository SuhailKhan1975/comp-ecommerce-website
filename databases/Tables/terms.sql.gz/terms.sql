-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Aug 22, 2020 at 08:42 PM
-- Server version: 5.7.26
-- PHP Version: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecom_store`
--

-- --------------------------------------------------------

--
-- Table structure for table `terms`
--

DROP TABLE IF EXISTS `terms`;
CREATE TABLE IF NOT EXISTS `terms` (
  `term_id` int(10) NOT NULL AUTO_INCREMENT,
  `term_title` varchar(100) NOT NULL,
  `term_link` varchar(100) NOT NULL,
  `term_desc` text NOT NULL,
  PRIMARY KEY (`term_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `terms`
--

INSERT INTO `terms` (`term_id`, `term_title`, `term_link`, `term_desc`) VALUES
(1, 'Term & conditions', 'termLink', '<p>Please read these Terms and Conditions (\"Terms\", \"Terms and Conditions\") carefully before using the http://www.mdevstore.com (change this) website. Your access to and use of the Service is conditioned on your acceptance of and compliance with these Terms. These Terms apply to all visitors, users and others who access or use the Service. By accessing or using the Service you agree to be bound by these Terms. If you disagree with any part of the terms then you may not access the Service. Purchases If you wish to purchase any product or service made available through the Service (\"Purchase\"), you may be asked to supply certain information relevant to your Purchase including, without limitation, your … The Purchases section is for businesses that sell online (physical or digital). For the full disclosure section, create your own Terms and Conditions. Subscriptions Some parts of the Service are billed on a subscription basis (\"Subscription(s)\"). You will be billed in advance on a recurring ... Our Service allows you to post, link, store, share and otherwise make available certain information, text, graphics, videos, or other material (\"Content\"). You are responsible for the … The Content section is for businesses that allow users to create, edit, share, make content on their websites or apps. For the full disclosure section, create your own Terms and Conditions. Links To Other Web Sites Our Service may contain links to third-party web sites or services that are not owned or controlled by MDEV Store. MDEV Store has no control over, and assumes no responsibility for, the content, privacy policies, or practices of any third party web sites or services. You further acknowledge and agree thatMDEV Store shall not be responsible or liable, directly or indirectly, for any damage or loss caused or alleged to be caused by or in connection with use of or reliance on any such content, goods or services available on or through any such web sites or services. Changes We reserve the right, at our sole discretion, to modify or replace these Terms at any time. If a revision is material we will try to provide at least 30 days\' notice prior to any new terms taking effect. What constitutes a material change will be determined at our sole discretion. Contact Us If you have any questions about these Terms, please contact us..</p>'),
(2, 'Refund', 'refundLink', 'Return & Refund Policy\r\nThanks for shopping at MDEV Store.\r\nIf you are not entirely satisfied with your purchase, we\'re here to help.\r\nReturns\r\nYou have 30 calendar days to return an item from the date you received it.\r\nTo be eligible for a return, your item must be unused and in the same condition that you received it.\r\nYour item must be in the original packaging.\r\nYour item needs to have the receipt or proof of purchase.\r\n'),
(3, 'Promotion and terms', 'promoLink', 'Workplace promotions may result from a new job opening, or from an upward reclassification of an existing position in the company. Factors that should be considered when determining the eligibility of an employee’s promotion include performance levels, skills, education, relevant experience and professional development.\r\nIn most companies, performance appraisal systems are utilized to evaluate employees generally, and for promotions. When an employee from within the company is involved, he should demonstrate current capacity to perform the duties at the next highest rank. In some companies, depending on the type of job involved, the hiring supervisor might be mandated to evaluate the employee’s performance ability in the new position for several months.'),
(5, 'Rules', 'rules', 'When you send out order confirmations, make sure to include all of the product details to re-assure the buyer that they\'ve selected properly. If I accidentally ordered the size 9 instead of size 8, I want to be able to fix it before the package arrives.\r\nReplicate this experience for your own customers, rather than leaving them in the dark (or, worse, crowding up your customer service dept. with e-mails that could have been answered in an automated fashion).');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
