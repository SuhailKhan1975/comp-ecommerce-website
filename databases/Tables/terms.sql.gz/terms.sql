-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 19, 2020 at 11:39 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecom_store`
--

-- --------------------------------------------------------

--
-- Table structure for table `terms`
--

CREATE TABLE `terms` (
  `term_id` int(10) NOT NULL,
  `term_title` varchar(100) NOT NULL,
  `term_link` varchar(100) NOT NULL,
  `term_desc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `terms`
--

INSERT INTO `terms` (`term_id`, `term_title`, `term_link`, `term_desc`) VALUES
(1, 'Term & conditions', 'termLink', '<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates aut nulla, perferendis assumenda amet beatae dolor. Labore ad sint repellendus omnis nisi, voluptas sed voluptates incidunt quasi rem perspiciatis dignissimos.</p>'),
(2, 'Refund', 'refundLink', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates aut nulla, perferendis assumenda amet beatae dolor. Labore ad sint repellendus omnis nisi, voluptas sed voluptates incidunt quasi rem perspiciatis dignissimos.'),
(3, 'Promotion and terms', 'promoLink', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates aut nulla, perferendis assumenda amet beatae dolor. Labore ad sint repellendus omnis nisi, voluptas sed voluptates incidunt quasi rem perspiciatis dignissimos.'),
(5, 'Rules', 'rules', '<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates aut nulla, perferendis assumenda amet beatae dolor. Labore ad sint repellendus omnis nisi, voluptas sed voluptates incidunt quasi rem perspiciatis dignissimos.</p>');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `terms`
--
ALTER TABLE `terms`
  ADD PRIMARY KEY (`term_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `terms`
--
ALTER TABLE `terms`
  MODIFY `term_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
