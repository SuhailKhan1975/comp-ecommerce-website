-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 19, 2020 at 11:38 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecom_store`
--

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(10) NOT NULL,
  `p_cat_id` int(10) NOT NULL,
  `cat_id` int(10) NOT NULL,
  `manufacturer_id` int(10) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `product_title` text NOT NULL,
  `product_url` text NOT NULL,
  `product_img1` text NOT NULL,
  `product_img2` text NOT NULL,
  `product_img3` text NOT NULL,
  `product_price` int(10) NOT NULL,
  `product_desc` text NOT NULL,
  `product_features` text NOT NULL,
  `product_video` text NOT NULL,
  `product_label` text NOT NULL,
  `product_sale` int(100) NOT NULL,
  `product_keywords` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `p_cat_id`, `cat_id`, `manufacturer_id`, `date`, `product_title`, `product_url`, `product_img1`, `product_img2`, `product_img3`, `product_price`, `product_desc`, `product_features`, `product_video`, `product_label`, `product_sale`, `product_keywords`) VALUES
(25, 3, 3, 1, '2020-08-19 07:33:54', 'Hp laptop', 'product-1', 'HP Laptop-15t.webp', 'HP Laptop-15t2.webp', 'HP Laptop-15t3.jpg', 90000, '<h2 class=\"showInDesk\" style=\"margin: 0.2em 0px 15px; padding: 0px; direction: ltr; font-family: HPSimplified, arial; font-weight: 100; color: #ffffff; text-rendering: optimizelegibility; line-height: 32px; font-size: 24px; box-sizing: border-box;\">Ultra-portable laptops to fit your lifestyle and allow you to create from anywhere</h2>', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Obcaecati porro quidem voluptate ducimus eum pariatur iusto alias aspernatur mollitia excepturi. Sapiente, inventore mollitia distinctio dicta quia sunt? Repudiandae, quam amet.', '<iframe width=\"640\" height=\"360\" src=\"https://www.youtube.com/embed/GFvaLRKY9pA\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>', 'sale', 30, 'Hp laptops, laptop'),
(26, 1, 2, 1, '2020-08-19 07:34:13', 'Dell Laptop', 'product-2', 'DELLlaptop1.jpg', 'DELLlaptop3.jpg', 'DELLlaptop2.jpg', 1200, '<h2 class=\"showInDesk\" style=\"margin: 0.2em 0px 15px; padding: 0px; direction: ltr; font-family: HPSimplified, arial; font-weight: 100; color: #ffffff; text-rendering: optimizelegibility; line-height: 32px; font-size: 24px; box-sizing: border-box;\">Ultra-portable laptops to fit your lifestyle and allow you to create from anywhere</h2>', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Obcaecati porro quidem voluptate ducimus eum pariatur iusto alias aspernatur mollitia excepturi. Sapiente, inventore mollitia distinctio dicta quia sunt? Repudiandae, quam amet.', '<iframe width=\"640\" height=\"360\" src=\"https://www.youtube.com/embed/GFvaLRKY9pA\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>', 'sale', 20, 'Dell laptops, laptop'),
(27, 5, 2, 3, '2020-08-19 07:33:59', 'Apple Elite', 'product-3', 'Apple Elite1.webp', 'Apple Elite2.webp', 'Apple Elite3.webp', 200, '<p>10th Gen Intel&reg; Core&trade; i7</p>', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Obcaecati porro quidem voluptate ducimus eum pariatur iusto alias aspernatur mollitia excepturi. Sapiente, inventore mollitia distinctio dicta quia sunt? Repudiandae, quam amet.', '<iframe width=\"640\" height=\"360\" src=\"https://www.youtube.com/embed/GFvaLRKY9pA\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>', 'new', 150, 'Apple laptops, laptop'),
(28, 4, 3, 4, '2020-08-19 07:34:03', 'Lenovo elite', 'product-4', 'Lenovo1.webp', 'Lenovo2.webp', 'Lenovo3.webp', 300, '<p>Windows 10 Home 64</p>\r\n<p>10th Generation Intel&reg; Core&trade; i7 processor</p>\r\n<p>NVIDIA&reg; GeForce RTX&trade; 2060 (6 GB GDDR6 dedicated)</p>\r\n<p>16 GB memory; 1 TB HDD storage; 512 GB SSD storage</p>\r\n<p>17.3\" diagonal FHD display</p>', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Obcaecati porro quidem voluptate ducimus eum pariatur iusto alias aspernatur mollitia excepturi. Sapiente, inventore mollitia distinctio dicta quia sunt? Repudiandae, quam amet.', '<iframe width=\"640\" height=\"360\" src=\"https://www.youtube.com/embed/GFvaLRKY9pA\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>', 'sale', 115, 'Lenovo laptop, laptops'),
(29, 2, 3, 3, '2020-08-19 07:34:06', 'HP ENVY Printer', 'product-5', 'printer1.webp', 'printer2.webp', 'printer3.webp', 179, '<p>Print, Scan, Copy, Web, Photo</p>\r\n<p>Print speed ISO: Up to 14 ppm black, up to 9 ppm color</p>\r\n<p>Go from memory card to photo printout with ease</p>\r\n<p>Instant Ink ready; High yield ink available</p>', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Obcaecati porro quidem voluptate ducimus eum pariatur iusto alias aspernatur mollitia excepturi. Sapiente, inventore mollitia distinctio dicta quia sunt? Repudiandae, quam amet.', '<iframe width=\"640\" height=\"360\" src=\"https://www.youtube.com/embed/GFvaLRKY9pA\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>', 'sale', 215, 'Printer, hp color, laserjet'),
(30, 3, 2, 2, '2020-08-19 07:34:09', 'HP Envvy', 'product-6', 'Hpenvy3.jpg', 'Hpenvy1.jpg', 'Hpenvy2.jpg', 300, '<p>Windows 10 Home 64</p>\r\n<p>10th Gen Intel&reg; Core&trade; i7 processor</p>\r\n<p>NVIDIA&reg; GeForce&reg; GTX 1660 Ti (6 GB)</p>\r\n<p>16 GB memory; 512 GB SSD storage</p>', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Obcaecati porro quidem voluptate ducimus eum pariatur iusto alias aspernatur mollitia excepturi. Sapiente, inventore mollitia distinctio dicta quia sunt? Repudiandae, quam amet.', '<iframe width=\"640\" height=\"360\" src=\"https://www.youtube.com/embed/GFvaLRKY9pA\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>', 'new', 64, 'Hp laptops, laptop');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
