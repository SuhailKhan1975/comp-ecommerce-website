-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Aug 22, 2020 at 08:40 PM
-- Server version: 5.7.26
-- PHP Version: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecom_store`
--

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `product_id` int(10) NOT NULL AUTO_INCREMENT,
  `p_cat_id` int(10) NOT NULL,
  `cat_id` int(10) NOT NULL,
  `manufacturer_id` int(10) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `product_title` text NOT NULL,
  `product_url` text NOT NULL,
  `product_img1` text NOT NULL,
  `product_img2` text NOT NULL,
  `product_img3` text NOT NULL,
  `product_price` int(10) NOT NULL,
  `product_desc` text NOT NULL,
  `product_features` text NOT NULL,
  `product_video` text NOT NULL,
  `product_label` text NOT NULL,
  `product_sale` int(100) NOT NULL,
  `product_keywords` text NOT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `p_cat_id`, `cat_id`, `manufacturer_id`, `date`, `product_title`, `product_url`, `product_img1`, `product_img2`, `product_img3`, `product_price`, `product_desc`, `product_features`, `product_video`, `product_label`, `product_sale`, `product_keywords`) VALUES
(20, 3, 3, 1, '2020-08-21 08:53:42', 'Hp laptop', 'product-1', 'HP Laptop-15t.webp', 'HP Laptop-15t2.webp', 'HP Laptop-15t3.jpg', 1500, '<p>As big as your imagination. The immersive, 17\" display allows you to easily create true-to-life visuals with stunning, accurate colors. Customizable performance puts the controls in your hands, and peace of mind features ensure your creations are safe-guarded until you&rsquo;re ready to share them.</p>\r\n<p><em><strong>The power to bring your creations to life</strong></em></p>\r\n<p>The powerful combination of an Intel&reg; Core&trade;</p>\r\n<p>Sometimes bigger is better. Watch your creations come to life in accurate, vibrant color on this massive high definition, micro-edge display.</p>\r\n<p><em><strong>Privacy for your peace of mind</strong></em></p>\r\n<p>Keep it confidential with an unhackable camera shutter and dedicated microphone mute button.</p>', '<p>Windows 10 Home 64</p>\r\n<p>10th Gen Intel&reg; Core&trade; i7 processor</p>\r\n<p>NVIDIA&reg; GeForce&reg; MX330 (4 GB)</p>\r\n<p>16 GB Memory; 1 TB SSD storage</p>\r\n<p>17.3\" diagonal FHD touch display</p>', '                                                                        <iframe width=\"640\" height=\"360\" src=\"https://www.youtube.com/embed/GFvaLRKY9pA\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>                                                                ', 'sale', 1000, 'Hp laptops, laptop'),
(22, 2, 1, 3, '2020-08-21 08:35:59', 'HP 90W Smart AC Adapter', '-', 'ddapter1.webp', 'adapter2.webp', 'ddapter1.webp', 60, '<p>Provide optimal power and help offset power fluctuations to your HP notebook with a HP 90W Smart AC Adapter. Now available with a new right-angled (90&deg;) connector that reduces cable stress and an optional 4.5mm to 7.4mm conversion dongle. As a replacement or back-up adapter, be prepared with the right connection.</p>', '<p>Compatibility</p>\r\n<p>HP Smart AC Adapters are compatible with all HP Business Notebooks and Tablet PCs NOTE: Not all models are available in all regions.</p>\r\n<p>Power: 90w</p>\r\n<p>Connector: 4.5mm(F)-7.4mm(M) dongle</p>\r\n<p>Dimensions (W X D X H): 4.92 x 1.97 x 1.18 in</p>\r\n<p>Weight: 0.72 lb</p>', '                                                                                                                                        ', 'sale', 50, 'Adapter'),
(23, 2, 1, 4, '2020-08-21 08:54:35', 'HP X3000 Wireless Mouse', '_', 'center_facing.webp', 'Mouse2.webp', 'Mouse3.webp', 12, '<p>Premium HP standards</p>\r\n<p>Stylish, attractive design</p>\r\n<p>No more pulling. No more tugging.</p>\r\n<p>Scroll wheel</p>', '<p>Color: Black; Metallic gray</p>\r\n<p>Buttons: 3 buttons; Scroll wheel</p>\r\n<p>Connector: USB wireless receiver at 27 MHz</p>\r\n<p>Wireless technology: 27MHz wireless technology</p>', '', 'sale', 10, 'Mouse, Wireless mouse'),
(26, 1, 2, 1, '2020-08-21 06:56:37', 'Dell Laptop', 'product-2', 'DELLlaptop1.jpg', 'DELLlaptop3.jpg', 'DELLlaptop2.jpg', 1200, '<p>Crisp gameplay is crucial if you want to play at your best. With a high resolution and refresh rate, on-screen visuals are swift and smooth, while a narrow bezel display delivers edge-to-edge immersion.</p>', '<p>Windows 10 Home 64</p>\r\n<p>10th Gen Intel&reg; Core&trade; i7 processor</p>\r\n<p>NVIDIA&reg; GeForce&reg; GTX 1660 Ti (6 GB)</p>\r\n<p>16 GB memory; 512 GB SSD storage</p>\r\n<p>17.3\" diagonal FHD display</p>', '                                    <iframe width=\"640\" height=\"360\" src=\"https://www.youtube.com/embed/GFvaLRKY9pA\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>                                ', 'sale', 20, 'Dell laptops, laptop'),
(27, 5, 2, 3, '2020-08-21 06:58:31', 'Apple Elite', 'product-3', 'Apple Elite1.webp', 'Apple Elite2.webp', 'Apple Elite3.webp', 2000, '<p>Designed for the modern mobile professional, the Apple EliteBook 745 delivers enterprise-grade security and manageability along with powerful collaboration features to keep you connected.</p>', '<p>Windows 10 Pro 64</p>\r\n<p>AMD PRO Ryzen-Series processor</p>\r\n<p>8 GB memory; 256 GB SSD storage</p>\r\n<p>14\" diagonal FHD display</p>', '                                    <iframe width=\"640\" height=\"360\" src=\"https://www.youtube.com/embed/GFvaLRKY9pA\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>                                ', 'new', 1700, 'Apple laptops, laptop'),
(28, 4, 3, 4, '2020-08-21 07:00:17', 'Lenovo elite', 'product-4', 'Lenovo1.webp', 'Lenovo2.webp', 'Lenovo3.webp', 400, '<p>Crystal-clear collaboration</p>\r\n<p>Calls sound crisp and clear with advanced collaboration features like Lenovo Noise Cancellation and an integrated with world-facing microphone. Loud top-firing speakers produce rich sound and collaboration keys help make PC calls productive.</p>', '<p>Windows 10 Home 64</p>\r\n<p>10th Generation Intel&reg; Core&trade; i7 processor</p>\r\n<p>NVIDIA&reg; GeForce RTX&trade; 2060 (6 GB GDDR6 dedicated)</p>\r\n<p>16 GB memory; 1 TB HDD storage; 512 GB SSD storage</p>\r\n<p>17.3\" diagonal FHD display</p>', '                                                                        <iframe width=\"640\" height=\"360\" src=\"https://www.youtube.com/embed/GFvaLRKY9pA\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>                                                                ', 'sale', 250, 'Lenovo laptop, laptops'),
(29, 2, 3, 3, '2020-08-21 07:02:13', 'HP ENVY Printer', 'product-5', 'printer1.webp', 'printer2.webp', 'printer3.webp', 179, '<p>Print, Scan, Copy, Web, Photo</p>\r\n<p>Print speed ISO: Up to 14 ppm black, up to 9 ppm color</p>\r\n<p>Go from memory card to photo printout with ease</p>\r\n<p>Instant Ink ready; High yield ink available</p>', '<h3 style=\"margin: 0px; padding: 0px; direction: ltr; font-family: HPSimplifiedLight; font-weight: normal; color: #222222; text-rendering: optimizelegibility; line-height: 40px; font-size: 24px; border: 0px; box-sizing: border-box;\">HP OfficeJet Pro Printers</h3>\r\n<p style=\"margin: 0px 0px 1em; padding: 0px; direction: ltr; font-family: HPSimplifiedLight; font-size: 18px; line-height: 26px; text-rendering: optimizelegibility; border: 0px; color: #767676; box-sizing: border-box;\">Print professional color for up to 50% lower cost per page than lasers,&nbsp;and use smart touch features to finish jobs fast.</p>', '                                    <iframe width=\"640\" height=\"360\" src=\"https://www.youtube.com/embed/GFvaLRKY9pA\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>                                ', 'sale', 215, 'Printer, hp color, laserjet'),
(31, 3, 2, 2, '2020-08-21 08:52:12', 'HP Envvy', 'product-6', 'Hpenvy3.jpg', 'Hpenvy1.jpg', 'Hpenvy2.jpg', 600, '<p>Envy745 G6 with AMD Ryzen 3 PRO 3300U processor + Integrated AMD Radeon Vega Graphics ( 5VU36AV )</p>\r\n<p>Envy 745 G6 with AMD Ryzen 5 PRO 3500U processor + Integrated AMD Radeon Vega Graphics ( 5VU37AV )</p>\r\n<p>Envy 745 G6 with AMD Ryzen 7 PRO 3700U processor + Integrated AMD Radeon Vega Graphics ( 5VU38AV )</p>', '<p>Windows 10 Home 64</p>\r\n<p>10th Gen Intel&reg; Core&trade; i7 processor</p>\r\n<p>NVIDIA&reg; GeForce&reg; GTX 1660 Ti (6 GB)</p>\r\n<p>16 GB memory; 512 GB SSD storage</p>', '                                    <iframe width=\"640\" height=\"360\" src=\"https://www.youtube.com/embed/GFvaLRKY9pA\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>                                ', 'new', 450, 'Hp laptops, laptop'),
(37, 2, 4, 5, '2020-08-21 09:05:45', 'HP Wireless Mouse 200', '_', 'wireless mouse1.webp', 'wireless mouse3.webp', 'wirelessMouse2.webp', 15, '<p>Wireless convenience</p>\r\n<p>Built to last</p>\r\n<p>Contoured comfort</p>\r\n<p>Good to go</p>\r\n<p>Reliability you can count on</p>', '<p>Color</p>\r\n<p>Pike silver</p>\r\n<p>Compatibility</p>\r\n<p>Available USB port.</p>\r\n<p>Minimum system requirements</p>\r\n<p>Windows 7 and above,[2]</p>\r\n<p>[2] Windows&reg; is either registered trademark or trademark of Microsoft Corporation in the United States and/or other countries. All other trademarks are the property of their respective owners. Actual product may vary from image shown:</p>\r\n<p>Mac OS 10.x and above, and Chrome OS.</p>\r\n<p>Dimensions (W X D X H): 3.74 x 2.3 x 1.34 in</p>\r\n<p>Weight: 0.17 lb</p>', '', 'sale', 13, 'Mouse, Wireless mouse');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
