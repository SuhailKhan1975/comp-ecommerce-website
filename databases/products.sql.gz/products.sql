-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Aug 10, 2020 at 07:16 AM
-- Server version: 5.7.26
-- PHP Version: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecom_store`
--

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `product_id` int(10) NOT NULL AUTO_INCREMENT,
  `p_cat_id` int(10) NOT NULL,
  `cat_id` int(10) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `product_title` text NOT NULL,
  `product_img1` text NOT NULL,
  `product_img2` text NOT NULL,
  `product_img3` text NOT NULL,
  `product_price` int(10) NOT NULL,
  `product_desc` text NOT NULL,
  `product_keywords` text NOT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `p_cat_id`, `cat_id`, `date`, `product_title`, `product_img1`, `product_img2`, `product_img3`, `product_price`, `product_desc`, `product_keywords`) VALUES
(25, 3, 3, '2020-08-07 18:12:35', 'Hp laptop', 'HP Laptop-15t.webp', 'HP Laptop-15t2.webp', 'HP Laptop-15t3.jpg', 90000, '<h2 class=\"showInDesk\" style=\"margin: 0.2em 0px 15px; padding: 0px; direction: ltr; font-family: HPSimplified, arial; font-weight: 100; color: #ffffff; text-rendering: optimizelegibility; line-height: 32px; font-size: 24px; box-sizing: border-box;\">Ultra-portable laptops to fit your lifestyle and allow you to create from anywhere</h2>', 'Hp laptops, laptop'),
(26, 1, 2, '2020-08-07 18:14:13', 'Dell Laptop', 'DELLlaptop1.jpg', 'DELLlaptop3.jpg', 'DELLlaptop2.jpg', 1200, '<h2 class=\"showInDesk\" style=\"margin: 0.2em 0px 15px; padding: 0px; direction: ltr; font-family: HPSimplified, arial; font-weight: 100; color: #ffffff; text-rendering: optimizelegibility; line-height: 32px; font-size: 24px; box-sizing: border-box;\">Ultra-portable laptops to fit your lifestyle and allow you to create from anywhere</h2>', 'Dell laptops, laptop'),
(27, 5, 2, '2020-08-07 18:23:50', 'Apple Elite', 'Apple Elite1.webp', 'Apple Elite2.webp', 'Apple Elite3.webp', 200, '<p>10th Gen Intel&reg; Core&trade; i7</p>', 'Apple laptops, laptop'),
(28, 4, 3, '2020-08-07 18:33:40', 'Lenovo elite', 'Lenovo1.webp', 'Lenovo2.webp', 'Lenovo3.webp', 300, '<p>Windows 10 Home 64</p>\r\n<p>10th Generation Intel&reg; Core&trade; i7 processor</p>\r\n<p>NVIDIA&reg; GeForce RTX&trade; 2060 (6 GB GDDR6 dedicated)</p>\r\n<p>16 GB memory; 1 TB HDD storage; 512 GB SSD storage</p>\r\n<p>17.3\" diagonal FHD display</p>', 'Lenovo laptop, laptops'),
(29, 2, 3, '2020-08-08 15:02:09', 'HP ENVY Printer', 'printer1.webp', 'printer2.webp', 'printer3.webp', 179, '<p>Print, Scan, Copy, Web, Photo</p>\r\n<p>Print speed ISO: Up to 14 ppm black, up to 9 ppm color</p>\r\n<p>Go from memory card to photo printout with ease</p>\r\n<p>Instant Ink ready; High yield ink available</p>', 'Printer, hp color, laserjet'),
(30, 3, 2, '2020-08-08 15:16:28', 'HP Envvy', 'Hpenvy3.jpg', 'Hpenvy1.jpg', 'Hpenvy2.jpg', 300, '<p>Windows 10 Home 64</p>\r\n<p>10th Gen Intel&reg; Core&trade; i7 processor</p>\r\n<p>NVIDIA&reg; GeForce&reg; GTX 1660 Ti (6 GB)</p>\r\n<p>16 GB memory; 512 GB SSD storage</p>', 'Hp laptops, laptop');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
