-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 19, 2020 at 11:33 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecom_store`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `admin_id` int(10) NOT NULL,
  `admin_name` varchar(255) NOT NULL,
  `admin_email` varchar(255) NOT NULL,
  `admin_pass` varchar(255) NOT NULL,
  `admin_image` text NOT NULL,
  `admin_country` text NOT NULL,
  `admin_about` text NOT NULL,
  `admin_contact` varchar(255) NOT NULL,
  `admin_job` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`admin_id`, `admin_name`, `admin_email`, `admin_pass`, `admin_image`, `admin_country`, `admin_about`, `admin_contact`, `admin_job`) VALUES
(1, 'Amjad Ahmed', 'ahmed@gmail.com', 'amj123', 'amjad.jpg', 'Pakistan', ' Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorem deleniti harum odio, aliquam ipsum impedit quisquam rem natus tempore aut officia suscipit reiciendis quas consequatur soluta maiores ad voluptas velit?', '03123456789', 'Accountant'),
(2, 'Kashif Ali', 'ali@gmail.com', 'kshf123', 'kashif.jpeg', 'USA', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequuntur tempora atque doloribus? Dolore incidunt delectus corrupti dignissimos, itaque aperiam laborum aliquid a officia, veritatis porro commodi obcaecati ex, recusandae quod.', '123456789', 'Developer'),
(3, 'Hammad Amir', 'hammad@gmail.com', 'amir123', 'amir.jpg', 'Pakistan', 'Work from home', '123456789', 'Contractor');

-- --------------------------------------------------------

--
-- Table structure for table `boxes_section`
--

CREATE TABLE `boxes_section` (
  `box_id` int(10) NOT NULL,
  `box_title` text NOT NULL,
  `box_desc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `boxes_section`
--

INSERT INTO `boxes_section` (`box_id`, `box_title`, `box_desc`) VALUES
(1, 'BEST OFFER', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.'),
(2, 'BEST PRICES', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.'),
(3, '  100% ORIGINAL  ', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.\r\nknkcnsk\r\nncksnkcn\r\nsjcnskcnakc\r\nakcnakcnnackna\r\nncknanclancla\r\nakcnnaknckack\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `p_id` int(10) NOT NULL,
  `ip_add` varchar(255) NOT NULL,
  `qty` int(10) NOT NULL,
  `p_price` varchar(255) NOT NULL,
  `size` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `cat_id` int(10) NOT NULL,
  `cat_title` text NOT NULL,
  `cat_top` text NOT NULL,
  `cat_image` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_title`, `cat_top`, `cat_image`) VALUES
(1, ' small ', 'yes', 'cat1.jpg'),
(2, 'middle', 'no', 'cat2.jpg'),
(3, 'large', 'no', 'cat3.jpg'),
(4, 'other', 'yes', 'cat4.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `coupons`
--

CREATE TABLE `coupons` (
  `coupon_id` int(100) NOT NULL,
  `product_id` int(100) NOT NULL,
  `coupon_title` varchar(255) NOT NULL,
  `coupon_price` varchar(255) NOT NULL,
  `coupon_code` varchar(255) NOT NULL,
  `coupon_limit` int(100) NOT NULL,
  `coupon_used` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `coupons`
--

INSERT INTO `coupons` (`coupon_id`, `product_id`, `coupon_title`, `coupon_price`, `coupon_code`, `coupon_limit`, `coupon_used`) VALUES
(1, 25, 'Coupon for Hp laptop', '215', '5451216', 3, 0);

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `customer_id` int(10) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `customer_email` varchar(255) NOT NULL,
  `customer_pass` varchar(255) NOT NULL,
  `customer_country` text NOT NULL,
  `customer_city` text NOT NULL,
  `customer_contact` varchar(255) NOT NULL,
  `customer_address` text NOT NULL,
  `customer_image` text NOT NULL,
  `customer_ip` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`customer_id`, `customer_name`, `customer_email`, `customer_pass`, `customer_country`, `customer_city`, `customer_contact`, `customer_address`, `customer_image`, `customer_ip`) VALUES
(2, 'Abc', 'abc@gmail.com', 'abcabc', 'America', 'Washington', '7328728223', 'Washington, America', 'Abdullah Khan.jpeg', '::1'),
(1, 'Asad', 'asad@gmail.com', 'asad123', 'USA', 'New York', '678219812', 'Newyork, USA', 'Director Talal Ashraf.jpeg', '::1');

-- --------------------------------------------------------

--
-- Table structure for table `customer_orders`
--

CREATE TABLE `customer_orders` (
  `order_id` int(10) NOT NULL,
  `customer_id` int(10) NOT NULL,
  `due_amount` int(100) NOT NULL,
  `invoice_no` int(100) NOT NULL,
  `qty` int(10) NOT NULL,
  `size` text NOT NULL,
  `order_date` date NOT NULL,
  `order_status` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_orders`
--

INSERT INTO `customer_orders` (`order_id`, `customer_id`, `due_amount`, `invoice_no`, `qty`, `size`, `order_date`, `order_status`) VALUES
(1, 1, 2400, 1627643586, 2, 'Medium', '2020-08-12', 'Complete'),
(2, 1, 179, 1627643586, 1, '', '2020-08-12', 'pending'),
(3, 1, 300, 1627643586, 1, 'Small', '2020-08-12', 'pending'),
(4, 1, 300, 1627643586, 1, 'Small', '2020-08-12', 'pending'),
(5, 2, 179, 18213711, 1, 'Small', '2020-08-19', 'pending'),
(6, 2, 115, 256560881, 1, 'Small', '2020-08-19', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `manufacturers`
--

CREATE TABLE `manufacturers` (
  `manufacturer_id` int(10) NOT NULL,
  `manufacturer_title` text NOT NULL,
  `manufacturer_top` text NOT NULL,
  `manufacturer_image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `manufacturers`
--

INSERT INTO `manufacturers` (`manufacturer_id`, `manufacturer_title`, `manufacturer_top`, `manufacturer_image`) VALUES
(1, 'Name_1', 'Yes', 'image1.jpg'),
(2, 'Name_2', 'no', 'image2.jpg'),
(3, 'Name_3', 'Yes', 'image3.jpg'),
(4, 'Name_4', 'no', 'image4.jpg'),
(5, 'Name_5', 'Yes', 'image5.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `payment_id` int(10) NOT NULL,
  `invoice_no` int(10) NOT NULL,
  `amount` int(10) NOT NULL,
  `payment_mode` text NOT NULL,
  `ref_no` int(10) NOT NULL,
  `code` int(10) NOT NULL,
  `payment_date` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`payment_id`, `invoice_no`, `amount`, `payment_mode`, `ref_no`, `code`, `payment_date`) VALUES
(1, 1627643586, 2400, 'Back Code', 2154, 65484, '12/08/2020');

-- --------------------------------------------------------

--
-- Table structure for table `pending_orders`
--

CREATE TABLE `pending_orders` (
  `order_id` int(10) NOT NULL,
  `customer_id` int(10) NOT NULL,
  `invoice_no` int(10) NOT NULL,
  `product_id` text NOT NULL,
  `qty` int(10) NOT NULL,
  `size` text NOT NULL,
  `order_status` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pending_orders`
--

INSERT INTO `pending_orders` (`order_id`, `customer_id`, `invoice_no`, `product_id`, `qty`, `size`, `order_status`) VALUES
(1, 1, 1627643586, '26', 2, 'Medium', 'Complete'),
(2, 1, 1627643586, '29', 1, '', 'pending'),
(3, 1, 1627643586, '30', 1, 'Small', 'pending'),
(5, 2, 18213711, '29', 1, 'Small', 'pending'),
(6, 2, 256560881, '28', 1, 'Small', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(10) NOT NULL,
  `p_cat_id` int(10) NOT NULL,
  `cat_id` int(10) NOT NULL,
  `manufacturer_id` int(10) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `product_title` text NOT NULL,
  `product_url` text NOT NULL,
  `product_img1` text NOT NULL,
  `product_img2` text NOT NULL,
  `product_img3` text NOT NULL,
  `product_price` int(10) NOT NULL,
  `product_desc` text NOT NULL,
  `product_features` text NOT NULL,
  `product_video` text NOT NULL,
  `product_label` text NOT NULL,
  `product_sale` int(100) NOT NULL,
  `product_keywords` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `p_cat_id`, `cat_id`, `manufacturer_id`, `date`, `product_title`, `product_url`, `product_img1`, `product_img2`, `product_img3`, `product_price`, `product_desc`, `product_features`, `product_video`, `product_label`, `product_sale`, `product_keywords`) VALUES
(25, 3, 3, 1, '2020-08-19 07:33:54', 'Hp laptop', 'product-1', 'HP Laptop-15t.webp', 'HP Laptop-15t2.webp', 'HP Laptop-15t3.jpg', 90000, '<h2 class=\"showInDesk\" style=\"margin: 0.2em 0px 15px; padding: 0px; direction: ltr; font-family: HPSimplified, arial; font-weight: 100; color: #ffffff; text-rendering: optimizelegibility; line-height: 32px; font-size: 24px; box-sizing: border-box;\">Ultra-portable laptops to fit your lifestyle and allow you to create from anywhere</h2>', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Obcaecati porro quidem voluptate ducimus eum pariatur iusto alias aspernatur mollitia excepturi. Sapiente, inventore mollitia distinctio dicta quia sunt? Repudiandae, quam amet.', '<iframe width=\"640\" height=\"360\" src=\"https://www.youtube.com/embed/GFvaLRKY9pA\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>', 'sale', 30, 'Hp laptops, laptop'),
(26, 1, 2, 1, '2020-08-19 07:34:13', 'Dell Laptop', 'product-2', 'DELLlaptop1.jpg', 'DELLlaptop3.jpg', 'DELLlaptop2.jpg', 1200, '<h2 class=\"showInDesk\" style=\"margin: 0.2em 0px 15px; padding: 0px; direction: ltr; font-family: HPSimplified, arial; font-weight: 100; color: #ffffff; text-rendering: optimizelegibility; line-height: 32px; font-size: 24px; box-sizing: border-box;\">Ultra-portable laptops to fit your lifestyle and allow you to create from anywhere</h2>', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Obcaecati porro quidem voluptate ducimus eum pariatur iusto alias aspernatur mollitia excepturi. Sapiente, inventore mollitia distinctio dicta quia sunt? Repudiandae, quam amet.', '<iframe width=\"640\" height=\"360\" src=\"https://www.youtube.com/embed/GFvaLRKY9pA\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>', 'sale', 20, 'Dell laptops, laptop'),
(27, 5, 2, 3, '2020-08-19 07:33:59', 'Apple Elite', 'product-3', 'Apple Elite1.webp', 'Apple Elite2.webp', 'Apple Elite3.webp', 200, '<p>10th Gen Intel&reg; Core&trade; i7</p>', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Obcaecati porro quidem voluptate ducimus eum pariatur iusto alias aspernatur mollitia excepturi. Sapiente, inventore mollitia distinctio dicta quia sunt? Repudiandae, quam amet.', '<iframe width=\"640\" height=\"360\" src=\"https://www.youtube.com/embed/GFvaLRKY9pA\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>', 'new', 150, 'Apple laptops, laptop'),
(28, 4, 3, 4, '2020-08-19 07:34:03', 'Lenovo elite', 'product-4', 'Lenovo1.webp', 'Lenovo2.webp', 'Lenovo3.webp', 300, '<p>Windows 10 Home 64</p>\r\n<p>10th Generation Intel&reg; Core&trade; i7 processor</p>\r\n<p>NVIDIA&reg; GeForce RTX&trade; 2060 (6 GB GDDR6 dedicated)</p>\r\n<p>16 GB memory; 1 TB HDD storage; 512 GB SSD storage</p>\r\n<p>17.3\" diagonal FHD display</p>', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Obcaecati porro quidem voluptate ducimus eum pariatur iusto alias aspernatur mollitia excepturi. Sapiente, inventore mollitia distinctio dicta quia sunt? Repudiandae, quam amet.', '<iframe width=\"640\" height=\"360\" src=\"https://www.youtube.com/embed/GFvaLRKY9pA\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>', 'sale', 115, 'Lenovo laptop, laptops'),
(29, 2, 3, 3, '2020-08-19 07:34:06', 'HP ENVY Printer', 'product-5', 'printer1.webp', 'printer2.webp', 'printer3.webp', 179, '<p>Print, Scan, Copy, Web, Photo</p>\r\n<p>Print speed ISO: Up to 14 ppm black, up to 9 ppm color</p>\r\n<p>Go from memory card to photo printout with ease</p>\r\n<p>Instant Ink ready; High yield ink available</p>', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Obcaecati porro quidem voluptate ducimus eum pariatur iusto alias aspernatur mollitia excepturi. Sapiente, inventore mollitia distinctio dicta quia sunt? Repudiandae, quam amet.', '<iframe width=\"640\" height=\"360\" src=\"https://www.youtube.com/embed/GFvaLRKY9pA\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>', 'sale', 215, 'Printer, hp color, laserjet'),
(30, 3, 2, 2, '2020-08-19 07:34:09', 'HP Envvy', 'product-6', 'Hpenvy3.jpg', 'Hpenvy1.jpg', 'Hpenvy2.jpg', 300, '<p>Windows 10 Home 64</p>\r\n<p>10th Gen Intel&reg; Core&trade; i7 processor</p>\r\n<p>NVIDIA&reg; GeForce&reg; GTX 1660 Ti (6 GB)</p>\r\n<p>16 GB memory; 512 GB SSD storage</p>', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Obcaecati porro quidem voluptate ducimus eum pariatur iusto alias aspernatur mollitia excepturi. Sapiente, inventore mollitia distinctio dicta quia sunt? Repudiandae, quam amet.', '<iframe width=\"640\" height=\"360\" src=\"https://www.youtube.com/embed/GFvaLRKY9pA\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>', 'new', 64, 'Hp laptops, laptop');

-- --------------------------------------------------------

--
-- Table structure for table `product_categories`
--

CREATE TABLE `product_categories` (
  `p_cat_id` int(10) NOT NULL,
  `p_cat_title` text NOT NULL,
  `p_cat_top` text NOT NULL,
  `p_cat_image` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_categories`
--

INSERT INTO `product_categories` (`p_cat_id`, `p_cat_title`, `p_cat_top`, `p_cat_image`) VALUES
(1, 'dell laptops', 'yes', 'p_cat_1.jpg'),
(2, 'hard drives\r\n', 'no', 'p_cat_2.jpg'),
(3, 'hp laptops', 'yes', 'p_cat_3.jpg'),
(4, 'lenovo laptops', 'no', 'p_cat_4.jpg'),
(5, 'apple laptops', 'no', 'p_cat_5.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `slider`
--

CREATE TABLE `slider` (
  `slide_Id` int(10) NOT NULL,
  `slide_name` varchar(255) NOT NULL,
  `slide_image` text NOT NULL,
  `slide_url` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `slider`
--

INSERT INTO `slider` (`slide_Id`, `slide_name`, `slide_image`, `slide_url`) VALUES
(1, 'slide number 1', '1.jpg', 'http://localhost/comp-ecommerce-website/m-dev-store/index.php'),
(2, 'slide number 2', '2.jpg', 'http://localhost/comp-ecommerce-website/m-dev-store/shop.php'),
(3, 'slide number 3', '3.jpg', 'http://localhost/comp-ecommerce-website/m-dev-store/contact.php'),
(5, 'slide number 4', '4.jpg', 'abc.com');

-- --------------------------------------------------------

--
-- Table structure for table `terms`
--

CREATE TABLE `terms` (
  `term_id` int(10) NOT NULL,
  `term_title` varchar(100) NOT NULL,
  `term_link` varchar(100) NOT NULL,
  `term_desc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `terms`
--

INSERT INTO `terms` (`term_id`, `term_title`, `term_link`, `term_desc`) VALUES
(1, 'Term & conditions', 'termLink', '<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates aut nulla, perferendis assumenda amet beatae dolor. Labore ad sint repellendus omnis nisi, voluptas sed voluptates incidunt quasi rem perspiciatis dignissimos.</p>'),
(2, 'Refund', 'refundLink', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates aut nulla, perferendis assumenda amet beatae dolor. Labore ad sint repellendus omnis nisi, voluptas sed voluptates incidunt quasi rem perspiciatis dignissimos.'),
(3, 'Promotion and terms', 'promoLink', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates aut nulla, perferendis assumenda amet beatae dolor. Labore ad sint repellendus omnis nisi, voluptas sed voluptates incidunt quasi rem perspiciatis dignissimos.'),
(5, 'Rules', 'rules', '<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates aut nulla, perferendis assumenda amet beatae dolor. Labore ad sint repellendus omnis nisi, voluptas sed voluptates incidunt quasi rem perspiciatis dignissimos.</p>');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `boxes_section`
--
ALTER TABLE `boxes_section`
  ADD PRIMARY KEY (`box_id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `coupons`
--
ALTER TABLE `coupons`
  ADD PRIMARY KEY (`coupon_id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `customer_orders`
--
ALTER TABLE `customer_orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `manufacturers`
--
ALTER TABLE `manufacturers`
  ADD PRIMARY KEY (`manufacturer_id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `pending_orders`
--
ALTER TABLE `pending_orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `product_categories`
--
ALTER TABLE `product_categories`
  ADD PRIMARY KEY (`p_cat_id`);

--
-- Indexes for table `slider`
--
ALTER TABLE `slider`
  ADD PRIMARY KEY (`slide_Id`);

--
-- Indexes for table `terms`
--
ALTER TABLE `terms`
  ADD PRIMARY KEY (`term_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `admin_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `boxes_section`
--
ALTER TABLE `boxes_section`
  MODIFY `box_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `cat_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `coupons`
--
ALTER TABLE `coupons`
  MODIFY `coupon_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `customer_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `customer_orders`
--
ALTER TABLE `customer_orders`
  MODIFY `order_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `manufacturers`
--
ALTER TABLE `manufacturers`
  MODIFY `manufacturer_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `payment_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pending_orders`
--
ALTER TABLE `pending_orders`
  MODIFY `order_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `product_categories`
--
ALTER TABLE `product_categories`
  MODIFY `p_cat_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `slider`
--
ALTER TABLE `slider`
  MODIFY `slide_Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `terms`
--
ALTER TABLE `terms`
  MODIFY `term_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
